<?php
// Verificar si se ha enviado el formulario
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Realizar el procesamiento del formulario aquí
    
    // Por ejemplo, puedes obtener los datos del formulario
    $nombre = $_POST["nombre"];
    $raza = $_POST["raza"];
    $edad = $_POST["edad"];
    $foto = $_POST["foto"];

    // Luego, puedes insertar estos datos en la base de datos
    include_once("conexion.php");
    $conexion = new Cconexion();
    $conn = $conexion->ConexionBD();

    if ($conn) {
        try {
            // Preparar la consulta para insertar un nuevo perro
            $stmt = $conn->prepare("INSERT INTO Perro (nombre, raza, edad, Foto) VALUES (:nombre, :raza, :edad, :foto)");
            // Vincular los parámetros
            $stmt->bindParam(':nombre', $nombre);
            $stmt->bindParam(':raza', $raza);
            $stmt->bindParam(':edad', $edad);
            $stmt->bindParam(':foto', $foto);
            // Ejecutar la consulta
            $stmt->execute();
            
            // Redirigir al usuario a una página de éxito
            header("Location: registro_exitoso.php");
            exit();
        } catch (PDOException $e) {
            // Manejar errores de la base de datos
            echo "Error al registrar el perro: " . $e->getMessage();
        }
    } else {
        echo "Error en la conexión a la base de datos";
    }
} else {
    // Si el formulario no se ha enviado, puedes redirigir al usuario al formulario de registro
    header("Location: formulario_registro_perro.html");
    exit();
}
?>
