document.addEventListener("DOMContentLoaded", () => {
    const form = document.getElementById("registroForm");
    const mensajeDiv = document.getElementById("mensaje");

    form.addEventListener("submit", async (event) => {
        event.preventDefault();

        const formData = new FormData(form);
        const response = await fetch("procesar.php", {
            method: "POST",
            body: formData,
        });

        const result = await response.text();
        mensajeDiv.textContent = result;
    });
});
