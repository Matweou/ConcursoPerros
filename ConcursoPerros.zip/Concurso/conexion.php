<?php
class Cconexion {
    private $conn;

    public function ConexionBD() {
        $servername = "localhost";
        $username = "root";
        $password = "12344321";
        $dbname = "concursoperros";

        try {
            $this->conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
            $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            return $this->conn;
        } catch (PDOException $e) {
            echo "No se pudo: concurso, error: " . $e->getMessage();
            return null;
        }
    }
    
}

?>
