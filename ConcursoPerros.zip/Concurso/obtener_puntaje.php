<?php
include_once("conexion.php");

if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET["nombre_perro"])) {
    $nombre_perro = $_GET["nombre_perro"];

    try {
        $conexion = new Cconexion();
        $conn = $conexion->ConexionBD();

        // Obtener el puntaje actualizado del perro
        $stmt = $conn->prepare("SELECT puntos FROM Concurso WHERE id_Perro = (SELECT id_Perro FROM Perro WHERE nombre = :nombre_perro)");
        $stmt->bindParam(':nombre_perro', $nombre_perro);
        $stmt->execute();
        $puntaje_actualizado = $stmt->fetch(PDO::FETCH_ASSOC)["puntos"];

        echo $puntaje_actualizado;
    } catch(PDOException $e) {
        echo "Error de conexión: " . $e->getMessage();
    }
}
?>
