<?php
include_once("conexion.php");

if (isset($_POST["buscar_perro"])) {
    // Obtener el nombre del perro a buscar
    $nombre_perro = $_POST["nombre_perro"];

    try {
        // Conectar a la base de datos usando la función de conexión del archivo de conexión
        $conexion = new Cconexion();
        $conn = $conexion->ConexionBD();

        // Consultar la base de datos para obtener la información del perro específico
        $stmt = $conn->prepare("SELECT nombre, raza, edad, foto FROM Perro WHERE nombre = :nombre");
        $stmt->bindParam(':nombre', $nombre_perro);
        $stmt->execute();

        // Obtener los resultados de la consulta
        $perro_encontrado = $stmt->fetch(PDO::FETCH_ASSOC);
    } catch(PDOException $e) {
        echo "Error de conexión: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Concurso de Perros</title>
    <link rel="stylesheet" href="styles.css">
    <script defer src="app.js"></script>
    <style>
        .container {
            display: flex;
        }
        .left {
            flex: 1;
            text-align: left;
        }
        .right {
            flex: 1;
        }
    </style>
</head>
<body>
    <h1>Registro de Perros</h1>
    <form id="registroForm">
        <label for="nombre">Nombre:</label>
        <input type="text" id="nombre" name="nombre" required>

        <label for="raza">Raza:</label>
        <input type="text" id="raza" name="raza" required>

        <label for="edad">Edad:</label>
        <input type="number" id="edad" name="edad" required>

        <label for="foto">Foto:</label>
        <input type="text" id="foto" name="foto" required>

        <button type="submit">Registrar</button>
    </form>

    <div id="mensaje"></div>
    <div class="container">
        <div class="left">
            <h2>Lista de Perros Registrados</h2>
            <table>
                <tr>
                    <th>Nombre</th>
                    <th>Raza</th>
                    <th>Edad</th>
                    <th>Puntos</th>
                </tr>
                <?php
                include_once("conexion.php");
                $conexion = new Cconexion();
                $conn = $conexion->ConexionBD();

                if ($conn) {
                    $orden = isset($_GET['orden']) ? $_GET['orden'] : 'raza'; // Orden por defecto: raza
                    $query = "SELECT * FROM Perro ORDER BY $orden";
                    $stmt = $conn->query($query);

                    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                        echo "<tr>";
                        echo "<td>" . $row['nombre'] . "</td>";
                        echo "<td>" . $row['raza'] . "</td>";
                        echo "<td>" . $row['edad'] . "</td>";
                        // Verificar si la clave 'puntos' está definida antes de intentar acceder a ella
                        echo "<td>" . (isset($row['puntos']) ? $row['puntos'] : 'N/A') . "</td>";
                        echo "</tr>";
                    }
                } else {
                    echo "Error en la conexión a la base de datos";
                }
                ?>
            </table>
        </div>
        <div class="right">
            <h2>Buscar un perro por su nombre</h2>
            <!-- Formulario para buscar un perro específico -->
            <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                <input type="text" name="nombre_perro" placeholder="Nombre del perro a buscar" required>
                <button type="submit" name="buscar_perro">Buscar Perro</button>
            </form>
            <!-- Mostrar la información del perro encontrado (si existe) -->
            <?php if (isset($perro_encontrado)) : ?>
                <h2>Información del Perro</h2>
                <p><strong>Nombre:</strong> <?php echo $perro_encontrado["nombre"]; ?></p>
                <p><strong>Raza:</strong> <?php echo $perro_encontrado["raza"]; ?></p>
                <p><strong>Edad:</strong> <?php echo $perro_encontrado["edad"]; ?></p>
                <img src="<?php echo $perro_encontrado["foto"]; ?>" alt="Foto del Perro">
            <?php endif; ?>
        </div>
    </div>
</body>
</html>
