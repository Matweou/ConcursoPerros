CREATE DATABASE ConcursoPerros;
USE ConcursoPerros;

/*----CREACION DE TABLAS----*/
create table Perro (
	id_Perro int auto_increment not null primary key,
    nombre varchar(25) not null,
    raza VARCHAR(50) NOT NULL,
    edad int not null,
    Foto varchar(200) not null
);

create table Competencia (
	id_C int auto_increment not null primary key,
    Circuito ENUM('Fácil', 'Medio', 'Dificil') NOT NULL
);

create table Calificar (
	id_puntaje int auto_increment not null primary key,
    id_Perro int not null,
    id_C int not null,
    Tiempo int not null,
    Puntos int not null,
    FOREIGN KEY (id_Perro) REFERENCES Perro(id_Perro),
    FOREIGN KEY (id_C) REFERENCES Competencia(id_C)
);
select * from Perro;