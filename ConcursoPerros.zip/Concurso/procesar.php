<?php
include_once("conexion.php");

$conexion = new Cconexion();
$conn = $conexion->ConexionBD();

if ($conn) {
    $nombre = $_POST['nombre'];
    $raza = $_POST['raza'];
    $edad = $_POST['edad'];
    $foto = $_POST['foto'];

    try {
        $stmt = $conn->prepare("INSERT INTO Perro (nombre, raza, edad, Foto) VALUES (:nombre, :raza, :edad, :foto)");
        $stmt->bindParam(':nombre', $nombre);
        $stmt->bindParam(':raza', $raza);
        $stmt->bindParam(':edad', $edad);
        $stmt->bindParam(':foto', $foto);
        $stmt->execute();
        echo "Registro exitoso";
    } catch (PDOException $e) {
        echo "Error al registrar: " . $e->getMessage();
    }
} else {
    echo "Error en la conexión a la base de datos";
}



?>
